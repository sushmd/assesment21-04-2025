const arr = [[3, 2, 1], [4, 5, 2], [1, 6]]
console.log("Flat and sort",arr.flat(Infinity).sort());

